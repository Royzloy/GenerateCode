import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import random
import re

class CodeGeneratorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Генератор кодов")
        self.geometry("700x750")
        self.resizable(True, True)

        # Переменные для управления состоянием
        self.use_digits = tk.BooleanVar(value=True)
        self.use_letters = tk.BooleanVar(value=True)
        self.order_mode = tk.StringVar(value="random")   # "random" или "unique"
        self.code_length = tk.IntVar(value=8)
        self.template_str = tk.StringVar(value="")
        self.use_hyphens = tk.BooleanVar(value=False)
        self.hyphen_interval = tk.IntVar(value=3)
        self.letters_mode = tk.StringVar(value="lang")   # "lang" или "custom"
        self.lang_choice = tk.StringVar(value="english") # "russian" или "english"
        self.custom_letters = tk.StringVar(value="")
        self.num_codes = tk.IntVar(value=1)

        self.create_widgets()
        self.update_widgets_state()

    def create_widgets(self):
        # Основной контейнер с прокруткой (если окно маленькое)
        main_frame = ttk.Frame(self)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 1. Рамка: использование символов
        chars_frame = ttk.LabelFrame(main_frame, text="Используемые символы")
        chars_frame.pack(fill=tk.X, pady=5)
        ttk.Checkbutton(chars_frame, text="Цифры (0-9)", variable=self.use_digits,
                        command=self.update_widgets_state).pack(side=tk.LEFT, padx=10, pady=5)
        ttk.Checkbutton(chars_frame, text="Буквы (заглавные)", variable=self.use_letters,
                        command=self.update_widgets_state).pack(side=tk.LEFT, padx=10, pady=5)

        # 2. Рамка: порядок символов
        order_frame = ttk.LabelFrame(main_frame, text="Порядок символов")
        order_frame.pack(fill=tk.X, pady=5)

        ttk.Radiobutton(order_frame, text="Рандомный (длина кода)", variable=self.order_mode,
                        value="random", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(order_frame, text="Уникальный (шаблон Б/Ц)", variable=self.order_mode,
                        value="unique", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        # Поле длины (рандомный)
        length_frame = ttk.Frame(order_frame)
        length_frame.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(length_frame, text="Длина кода:").pack(side=tk.LEFT)
        self.length_entry = ttk.Entry(length_frame, textvariable=self.code_length, width=6)
        self.length_entry.pack(side=tk.LEFT, padx=5)

        # Поле шаблона (уникальный)
        template_frame = ttk.Frame(order_frame)
        template_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(template_frame, text="Шаблон (Б=буква, Ц=цифра):").pack(side=tk.LEFT)
        self.template_entry = ttk.Entry(template_frame, textvariable=self.template_str, width=20)
        self.template_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(template_frame, text="Пример: ББЦЦЦ").pack(side=tk.LEFT, padx=5)

        # 3. Рамка: дефисы
        hyphens_frame = ttk.LabelFrame(main_frame, text="Дефисы")
        hyphens_frame.pack(fill=tk.X, pady=5)
        self.hyphens_check = ttk.Checkbutton(hyphens_frame, text="Использовать дефисы",
                                             variable=self.use_hyphens, command=self.update_widgets_state)
        self.hyphens_check.pack(side=tk.LEFT, padx=10, pady=5)
        interval_frame = ttk.Frame(hyphens_frame)
        interval_frame.pack(side=tk.LEFT, padx=10, pady=5)
        ttk.Label(interval_frame, text="Через каждые N символов:").pack(side=tk.LEFT)
        self.interval_entry = ttk.Entry(interval_frame, textvariable=self.hyphen_interval, width=5)
        self.interval_entry.pack(side=tk.LEFT, padx=5)

        # 4. Рамка: выбор букв
        letters_frame = ttk.LabelFrame(main_frame, text="Набор букв")
        letters_frame.pack(fill=tk.X, pady=5)

        # Радиокнопки для типа набора букв
        ttk.Radiobutton(letters_frame, text="Язычный", variable=self.letters_mode,
                        value="lang", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(letters_frame, text="Уникальный (пользовательский)", variable=self.letters_mode,
                        value="custom", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        # Подвыбор языков
        lang_subframe = ttk.Frame(letters_frame)
        lang_subframe.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Radiobutton(lang_subframe, text="Русский", variable=self.lang_choice,
                        value="russian").pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(lang_subframe, text="Английский", variable=self.lang_choice,
                        value="english").pack(side=tk.LEFT, padx=5)
        self.lang_subframe = lang_subframe

        # Поле для уникального набора букв
        custom_frame = ttk.Frame(letters_frame)
        custom_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(custom_frame, text="Набор букв:").pack(side=tk.LEFT)
        self.custom_entry = ttk.Entry(custom_frame, textvariable=self.custom_letters, width=20)
        self.custom_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(custom_frame, text="(только заглавные, пример: ABCXYZ)").pack(side=tk.LEFT, padx=5)

        # 5. Количество кодов и кнопка генерации
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=10)
        ttk.Label(control_frame, text="Количество кодов:").pack(side=tk.LEFT, padx=5)
        self.num_codes_entry = ttk.Entry(control_frame, textvariable=self.num_codes, width=6)
        self.num_codes_entry.pack(side=tk.LEFT, padx=5)
        self.generate_btn = ttk.Button(control_frame, text="Сгенерировать", command=self.generate_codes)
        self.generate_btn.pack(side=tk.LEFT, padx=20)

        # 6. Поле вывода результата
        output_frame = ttk.LabelFrame(main_frame, text="Результат")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.output_text = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD, height=15)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def update_widgets_state(self):
        """Обновляет состояние (активно/неактивно) полей в зависимости от выбранных опций."""
        # Поля для порядка символов
        if self.order_mode.get() == "random":
            self.length_entry.config(state="normal")
            self.template_entry.config(state="disabled")
        else:  # unique
            self.length_entry.config(state="disabled")
            self.template_entry.config(state="normal")

        # Поля для дефисов
        if self.use_hyphens.get():
            self.interval_entry.config(state="normal")
        else:
            self.interval_entry.config(state="disabled")

        # Поля для букв
        if self.letters_mode.get() == "lang":
            # Язычный режим: включаем выбор языка, отключаем поле уникального набора
            for child in self.lang_subframe.winfo_children():
                if isinstance(child, ttk.Radiobutton):
                    child.config(state="normal")
            self.custom_entry.config(state="disabled")
        else:  # custom
            # Уникальный режим: отключаем выбор языка, включаем поле ввода
            for child in self.lang_subframe.winfo_children():
                if isinstance(child, ttk.Radiobutton):
                    child.config(state="disabled")
            self.custom_entry.config(state="normal")

        # Дополнительно: если чекбоксы цифр и букв оба выключены, можно предупреждать при генерации
        # Здесь просто управление, проверки будут в generate_codes

    def get_letter_pool(self):
        """Возвращает строку из доступных букв согласно настройкам."""
        if self.letters_mode.get() == "lang":
            if self.lang_choice.get() == "russian":
                return "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
            else:  # english
                return "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        else:  # custom
            letters = self.custom_letters.get().strip().upper()
            # Убираем возможные дубликаты? Можно оставить как есть, но лучше уникальные?
            # По заданию просто набор, можно оставить как ввёл пользователь, дубли не страшны.
            return letters

    def generate_random_code(self, length, digits_enabled, letters_enabled, letter_pool):
        """Генерация кода в случайном порядке."""
        pool = []
        if digits_enabled:
            pool.extend("0123456789")
        if letters_enabled:
            pool.extend(letter_pool)
        # pool гарантированно не пуст из-за проверок
        return ''.join(random.choice(pool) for _ in range(length))

    def generate_unique_code(self, template, digits_enabled, letters_enabled, letter_pool):
        """Генерация кода по шаблону (Б/Ц)."""
        code_chars = []
        for ch in template:
            if ch == 'Б':
                if not letters_enabled:
                    # По идее не должно случиться из-за проверки, но на всякий случай
                    raise ValueError("Буквы не разрешены, но шаблон требует букву")
                code_chars.append(random.choice(letter_pool))
            elif ch == 'Ц':
                if not digits_enabled:
                    raise ValueError("Цифры не разрешены, но шаблон требует цифру")
                code_chars.append(random.choice("0123456789"))
            else:
                # Недопустимый символ в шаблоне - ошибка
                raise ValueError(f"Недопустимый символ в шаблоне: {ch}")
        return ''.join(code_chars)

    def insert_hyphens(self, code, interval):
        """Вставляет дефисы в строку через каждые interval символов."""
        if interval <= 0:
            return code
        parts = [code[i:i+interval] for i in range(0, len(code), interval)]
        return '-'.join(parts)

    def generate_codes(self):
        """Основная функция генерации, вызывается по кнопке."""
        # Сброс вывода
        self.output_text.delete(1.0, tk.END)

        # 1. Проверка: хотя бы один из чекбоксов (цифры/буквы) включён
        digits_enabled = self.use_digits.get()
        letters_enabled = self.use_letters.get()
        if not digits_enabled and not letters_enabled:
            messagebox.showerror("Ошибка", "Необходимо выбрать хотя бы один тип символов: цифры или буквы.")
            return

        # 2. Проверка количества кодов
        try:
            num = self.num_codes.get()
            if num <= 0:
                raise ValueError
        except:
            messagebox.showerror("Ошибка", "Количество кодов должно быть положительным целым числом.")
            return

        # 3. Получение набора букв (если нужен)
        letter_pool = ""
        if letters_enabled:
            if self.letters_mode.get() == "lang":
                # Язычный режим: выбран русский или английский (по умолчанию есть)
                # Проверка не нужна, всегда что-то выбрано
                letter_pool = self.get_letter_pool()
            else:  # custom
                custom = self.custom_letters.get().strip().upper()
                if not custom:
                    messagebox.showerror("Ошибка", "В режиме 'Уникальный набор букв' необходимо указать набор букв.")
                    return
                letter_pool = custom

        # 4. Проверка параметров в зависимости от режима порядка
        mode = self.order_mode.get()
        if mode == "random":
            try:
                length = self.code_length.get()
                if length <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Длина кода должна быть положительным целым числом.")
                return
        else:  # unique
            template = self.template_str.get().strip().upper()
            if not template:
                messagebox.showerror("Ошибка", "Шаблон не может быть пустым.")
                return
            # Проверка, что шаблон состоит только из Б и Ц
            if not re.fullmatch(r'[БЦ]+', template):
                messagebox.showerror("Ошибка", "Шаблон может содержать только символы 'Б' и 'Ц' (заглавные).")
                return
            # Дополнительно: проверить, что если в шаблоне есть буквы, то разрешены буквы, и аналогично цифры
            if 'Б' in template and not letters_enabled:
                messagebox.showerror("Ошибка", "Шаблон содержит буквы ('Б'), но использование букв отключено.")
                return
            if 'Ц' in template and not digits_enabled:
                messagebox.showerror("Ошибка", "Шаблон содержит цифры ('Ц'), но использование цифр отключено.")
                return
            length = len(template)  # для дефисов

        # 5. Дефисы
        use_hyphens = self.use_hyphens.get()
        interval = None
        if use_hyphens:
            try:
                interval = self.hyphen_interval.get()
                if interval <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Интервал для дефисов должен быть положительным целым числом.")
                return

        # 6. Генерация кодов
        codes = []
        for i in range(num):
            try:
                if mode == "random":
                    code = self.generate_random_code(length, digits_enabled, letters_enabled, letter_pool)
                else:
                    template = self.template_str.get().strip().upper()
                    code = self.generate_unique_code(template, digits_enabled, letters_enabled, letter_pool)
                if use_hyphens:
                    code = self.insert_hyphens(code, interval)
                codes.append(code)
            except Exception as e:
                messagebox.showerror("Ошибка генерации", str(e))
                return

        # 7. Вывод результата
        result_text = "\n".join(codes)
        self.output_text.insert(1.0, result_text)

if __name__ == "__main__":
    app = CodeGeneratorApp()
    app.mainloop()