import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, scrolledtext, filedialog
import random
import re
import json
import os
import webbrowser
import urllib.parse
import csv

# Попытка импорта openpyxl для Excel
try:
    from openpyxl import Workbook
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

class CodeGeneratorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Генератор кодов")
        self.geometry("750x850")
        self.resizable(True, True)

        # Переменные для настроек генерации
        self.use_digits = tk.BooleanVar(value=True)
        self.use_letters = tk.BooleanVar(value=True)
        self.use_lowercase = tk.BooleanVar(value=False)
        self.digits_mode = tk.StringVar(value="standard")
        self.custom_digits = tk.StringVar(value="")
        self.order_mode = tk.StringVar(value="random")
        self.code_length = tk.IntVar(value=8)
        self.template_str = tk.StringVar(value="")
        self.use_hyphens = tk.BooleanVar(value=False)
        self.hyphen_interval = tk.IntVar(value=3)
        self.letters_mode = tk.StringVar(value="lang")
        self.lang_choice = tk.StringVar(value="english")
        self.custom_letters = tk.StringVar(value="")
        self.num_codes = tk.IntVar(value=1)

        # Файл шаблонов
        self.templates_file = "templates.json"
        self.templates = {}
        self.load_templates()

        # Переменная для debounce предпросмотра
        self.preview_after_id = None

        # Создание интерфейса
        self.create_menu()
        self.create_widgets()
        self.update_widgets_state()

        # Привязка горячих клавиш
        self.bind_shortcuts()

        # Начальный предпросмотр
        self.update_preview()

        # Отслеживание изменений параметров для предпросмотра
        self.setup_preview_trace()

    # --------------------------------------------------------------------------
    # Загрузка и сохранение шаблонов
    # --------------------------------------------------------------------------
    def load_templates(self):
        if os.path.exists(self.templates_file):
            try:
                with open(self.templates_file, 'r', encoding='utf-8') as f:
                    self.templates = json.load(f)
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить шаблоны:\n{e}")
                self.templates = {}
        else:
            self.templates = {}

    def save_templates(self):
        try:
            with open(self.templates_file, 'w', encoding='utf-8') as f:
                json.dump(self.templates, f, ensure_ascii=False, indent=2)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить шаблоны:\n{e}")

    def get_current_settings(self):
        settings = {
            "template_version": "1.1.3",
            "use_digits": self.use_digits.get(),
            "use_letters": self.use_letters.get(),
            "use_lowercase": self.use_lowercase.get(),
            "digits_mode": self.digits_mode.get(),
            "custom_digits": self.custom_digits.get().strip(),
            "order_mode": self.order_mode.get(),
            "random_length": self.code_length.get(),
            "unique_pattern": self.template_str.get().strip(),
            "use_hyphens": self.use_hyphens.get(),
            "hyphen_interval": self.hyphen_interval.get(),
            "letters_mode": self.letters_mode.get(),
            "letters_language": self.lang_choice.get(),
            "custom_letters": self.custom_letters.get().strip().upper(),
            "num_codes": self.num_codes.get()
        }
        return settings

    def apply_settings(self, settings):
        self.use_digits.set(settings.get("use_digits", True))
        self.use_letters.set(settings.get("use_letters", True))
        self.use_lowercase.set(settings.get("use_lowercase", False))
        self.digits_mode.set(settings.get("digits_mode", "standard"))
        self.custom_digits.set(settings.get("custom_digits", ""))
        self.order_mode.set(settings.get("order_mode", "random"))
        self.code_length.set(settings.get("random_length", 8))
        self.template_str.set(settings.get("unique_pattern", ""))
        self.use_hyphens.set(settings.get("use_hyphens", False))
        self.hyphen_interval.set(settings.get("hyphen_interval", 3))
        self.letters_mode.set(settings.get("letters_mode", "lang"))
        self.lang_choice.set(settings.get("letters_language", "english"))
        self.custom_letters.set(settings.get("custom_letters", ""))
        self.num_codes.set(settings.get("num_codes", 1))
        self.update_widgets_state()
        self.update_preview()

    def save_current_as_template(self, event=None):
        name = simpledialog.askstring("Сохранить шаблон", "Введите имя шаблона:")
        if not name:
            return
        if name in self.templates:
            overwrite = messagebox.askyesno("Подтверждение",
                                            f"Шаблон с именем '{name}' уже существует. Перезаписать?")
            if not overwrite:
                return
        self.templates[name] = self.get_current_settings()
        self.save_templates()
        self.update_templates_list()
        messagebox.showinfo("Успех", f"Шаблон '{name}' сохранён.")

    def delete_template(self, name):
        if name in self.templates:
            del self.templates[name]
            self.save_templates()
            self.update_templates_list()
            messagebox.showinfo("Успех", f"Шаблон '{name}' удалён.")

    def apply_template(self, name):
        if name not in self.templates:
            messagebox.showerror("Ошибка", f"Шаблон '{name}' не найден.")
            return
        settings = self.templates[name]
        self.apply_settings(settings)
        self.notebook.select(0)
        messagebox.showinfo("Шаблон применён", f"Настройки из шаблона '{name}' загружены.")

    def update_templates_list(self):
        if hasattr(self, 'templates_listbox'):
            self.templates_listbox.delete(0, tk.END)
            for name in sorted(self.templates.keys()):
                self.templates_listbox.insert(tk.END, name)

    # --------------------------------------------------------------------------
    # Импорт/экспорт шаблонов в .gcs
    # --------------------------------------------------------------------------
    def export_template(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон для экспорта.")
            return
        name = self.templates_listbox.get(selection[0])
        settings = self.templates.get(name)
        if not settings:
            messagebox.showerror("Ошибка", "Не удалось получить настройки шаблона.")
            return
        file_path = filedialog.asksaveasfilename(
            defaultextension=".gcs",
            filetypes=[("Generation Code Settings", "*.gcs"), ("Все файлы", "*.*")],
            initialfile=f"{name}.gcs"
        )
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(settings, f, ensure_ascii=False, indent=2)
                messagebox.showinfo("Успех", f"Шаблон '{name}' экспортирован в {file_path}")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось экспортировать шаблон:\n{e}")

    def import_template(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("Generation Code Settings", "*.gcs"), ("Все файлы", "*.*")]
        )
        if not file_path:
            return
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                imported = json.load(f)
            if not isinstance(imported, dict):
                raise ValueError("Неверный формат файла")
            name = simpledialog.askstring("Импорт шаблона", "Введите имя для импортируемого шаблона:")
            if not name:
                return
            if name in self.templates:
                overwrite = messagebox.askyesno("Подтверждение",
                                                f"Шаблон с именем '{name}' уже существует. Перезаписать?")
                if not overwrite:
                    base = name
                    counter = 1
                    while f"{base}_импорт{counter}" in self.templates:
                        counter += 1
                    name = f"{base}_импорт{counter}"
                    messagebox.showinfo("Информация", f"Шаблон будет сохранён как '{name}'")
            self.templates[name] = imported
            self.save_templates()
            self.update_templates_list()
            messagebox.showinfo("Успех", f"Шаблон '{name}' импортирован.")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось импортировать шаблон:\n{e}")

    # --------------------------------------------------------------------------
    # Предпросмотр (live preview)
    # --------------------------------------------------------------------------
    def setup_preview_trace(self):
        vars_to_trace = [
            self.use_digits, self.use_letters, self.use_lowercase,
            self.digits_mode, self.custom_digits,
            self.order_mode, self.code_length, self.template_str,
            self.use_hyphens, self.hyphen_interval,
            self.letters_mode, self.lang_choice, self.custom_letters
        ]
        for var in vars_to_trace:
            var.trace_add('write', lambda *args: self.schedule_preview_update())

    def schedule_preview_update(self):
        if self.preview_after_id:
            self.after_cancel(self.preview_after_id)
        self.preview_after_id = self.after(300, self.update_preview)

    def update_preview(self):
        original_num = self.num_codes.get()
        self.num_codes.set(1)
        try:
            if self.preview_after_id:
                self.after_cancel(self.preview_after_id)
                self.preview_after_id = None
            code = self.generate_single_code()
            self.preview_value.config(state="normal")
            self.preview_value.delete(0, tk.END)
            if code:
                self.preview_value.insert(0, code)
            else:
                self.preview_value.insert(0, "Ошибка генерации")
            self.preview_value.config(state="readonly")
        except Exception as e:
            self.preview_value.config(state="normal")
            self.preview_value.delete(0, tk.END)
            self.preview_value.insert(0, f"Ошибка: {str(e)}")
            self.preview_value.config(state="readonly")
        finally:
            self.num_codes.set(original_num)

    def generate_single_code(self):
        digits_enabled = self.use_digits.get()
        letters_upper_enabled = self.use_letters.get()
        letters_lower_enabled = self.use_lowercase.get()
        if not digits_enabled and not letters_upper_enabled and not letters_lower_enabled:
            return None

        digits_pool = ""
        if digits_enabled:
            if self.digits_mode.get() == "standard":
                digits_pool = "0123456789"
            else:
                custom_digits = self.custom_digits.get().strip()
                if not custom_digits or not re.fullmatch(r'[0-9]+', custom_digits):
                    return None
                digits_pool = custom_digits

        upper_pool, lower_pool = "", ""
        if letters_upper_enabled or letters_lower_enabled:
            if self.letters_mode.get() == "lang":
                if self.lang_choice.get() == "russian":
                    base = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
                else:
                    base = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                if letters_upper_enabled:
                    upper_pool = base
                if letters_lower_enabled:
                    lower_pool = base.lower()
            else:
                custom_letters = self.custom_letters.get().strip()
                if not custom_letters:
                    return None
                if letters_upper_enabled:
                    upper_pool = custom_letters.upper()
                if letters_lower_enabled:
                    lower_pool = ''.join(ch.lower() for ch in custom_letters)

        mode = self.order_mode.get()
        if mode == "random":
            try:
                length = self.code_length.get()
                if length <= 0:
                    return None
            except:
                return None
            pool = []
            if digits_pool:
                pool.extend(digits_pool)
            if upper_pool:
                pool.extend(upper_pool)
            if lower_pool:
                pool.extend(lower_pool)
            if not pool:
                return None
            code = ''.join(random.choice(pool) for _ in range(length))
        else:
            template = self.template_str.get().strip().upper()
            if not template or not re.fullmatch(r'[БЦ]+', template):
                return None
            if 'Б' in template and not (letters_upper_enabled or letters_lower_enabled):
                return None
            if 'Ц' in template and not digits_enabled:
                return None
            code_chars = []
            for ch in template:
                if ch == 'Б':
                    available = []
                    if upper_pool:
                        available.extend(upper_pool)
                    if lower_pool:
                        available.extend(lower_pool)
                    if not available:
                        return None
                    code_chars.append(random.choice(available))
                else:
                    code_chars.append(random.choice(digits_pool))
            code = ''.join(code_chars)

        if self.use_hyphens.get():
            interval = self.hyphen_interval.get()
            if interval > 0:
                parts = [code[i:i+interval] for i in range(0, len(code), interval)]
                code = '-'.join(parts)
        return code

    # --------------------------------------------------------------------------
    # Основная генерация (множество кодов)
    # --------------------------------------------------------------------------
    def generate_codes(self, event=None):
        self.output_text.delete(1.0, tk.END)
        digits_enabled = self.use_digits.get()
        letters_upper_enabled = self.use_letters.get()
        letters_lower_enabled = self.use_lowercase.get()
        if not digits_enabled and not letters_upper_enabled and not letters_lower_enabled:
            messagebox.showerror("Ошибка", "Необходимо выбрать хотя бы один тип символов: цифры, заглавные буквы или строчные буквы.")
            return

        try:
            num = self.num_codes.get()
            if num <= 0:
                raise ValueError
        except:
            messagebox.showerror("Ошибка", "Количество кодов должно быть положительным целым числом.")
            return

        digits_pool = ""
        if digits_enabled:
            if self.digits_mode.get() == "standard":
                digits_pool = "0123456789"
            else:
                custom_digits = self.custom_digits.get().strip()
                if not custom_digits:
                    messagebox.showerror("Ошибка", "В режиме 'Уникальные цифры' необходимо указать набор цифр.")
                    return
                if not re.fullmatch(r'[0-9]+', custom_digits):
                    messagebox.showerror("Ошибка", "Набор уникальных цифр может содержать только цифры (0-9).")
                    return
                digits_pool = custom_digits

        upper_pool, lower_pool = "", ""
        if letters_upper_enabled or letters_lower_enabled:
            if self.letters_mode.get() == "lang":
                if self.lang_choice.get() == "russian":
                    base = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
                else:
                    base = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                if letters_upper_enabled:
                    upper_pool = base
                if letters_lower_enabled:
                    lower_pool = base.lower()
            else:
                custom_letters = self.custom_letters.get().strip()
                if not custom_letters:
                    messagebox.showerror("Ошибка", "В режиме 'Уникальный набор букв' необходимо указать набор букв.")
                    return
                if letters_upper_enabled:
                    upper_pool = custom_letters.upper()
                if letters_lower_enabled:
                    lower_pool = ''.join(ch.lower() for ch in custom_letters)

        mode = self.order_mode.get()
        if mode == "random":
            try:
                length = self.code_length.get()
                if length <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Длина кода должна быть положительным целым числом.")
                return
        else:
            template = self.template_str.get().strip().upper()
            if not template:
                messagebox.showerror("Ошибка", "Шаблон не может быть пустым.")
                return
            if not re.fullmatch(r'[БЦ]+', template):
                messagebox.showerror("Ошибка", "Шаблон может содержать только символы 'Б' и 'Ц'.")
                return
            if 'Б' in template and not (letters_upper_enabled or letters_lower_enabled):
                messagebox.showerror("Ошибка", "Шаблон содержит буквы ('Б'), но использование букв отключено.")
                return
            if 'Ц' in template and not digits_enabled:
                messagebox.showerror("Ошибка", "Шаблон содержит цифры ('Ц'), но использование цифр отключено.")
                return

        use_hyphens = self.use_hyphens.get()
        interval = None
        if use_hyphens:
            try:
                interval = self.hyphen_interval.get()
                if interval <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Интервал для дефисов должен быть положительным целым числом.")
                return

        codes = []
        for _ in range(num):
            try:
                if mode == "random":
                    pool = []
                    if digits_pool:
                        pool.extend(digits_pool)
                    if upper_pool:
                        pool.extend(upper_pool)
                    if lower_pool:
                        pool.extend(lower_pool)
                    if not pool:
                        raise ValueError("Нет доступных символов")
                    code = ''.join(random.choice(pool) for _ in range(length))
                else:
                    template = self.template_str.get().strip().upper()
                    code_chars = []
                    for ch in template:
                        if ch == 'Б':
                            available = []
                            if upper_pool:
                                available.extend(upper_pool)
                            if lower_pool:
                                available.extend(lower_pool)
                            if not available:
                                raise ValueError("Нет доступных букв")
                            code_chars.append(random.choice(available))
                        else:
                            code_chars.append(random.choice(digits_pool))
                    code = ''.join(code_chars)
                if use_hyphens and interval:
                    code = '-'.join([code[i:i+interval] for i in range(0, len(code), interval)])
                codes.append(code)
            except Exception as e:
                messagebox.showerror("Ошибка генерации", str(e))
                return

        self.output_text.insert(1.0, "\n".join(codes))

    # --------------------------------------------------------------------------
    # Функции для меню
    # --------------------------------------------------------------------------
    def save_result_to_file(self, event=None):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет сгенерированных кодов для сохранения.")
            return
        file_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")],
            title="Сохранить результат"
        )
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                messagebox.showinfo("Успех", f"Результат сохранён в:\n{file_path}")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось сохранить файл:\n{e}")

    def export_csv_excel(self):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет сгенерированных кодов для экспорта.")
            return
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV файлы", "*.csv"), ("Excel файлы", "*.xlsx"), ("Все файлы", "*.*")],
            title="Экспорт в CSV/Excel"
        )
        if not file_path:
            return
        ext = os.path.splitext(file_path)[1].lower()
        lines = content.splitlines()
        try:
            if ext == '.csv':
                with open(file_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    for line in lines:
                        writer.writerow([line])
                messagebox.showinfo("Успех", f"Экспорт в CSV выполнен:\n{file_path}")
            elif ext == '.xlsx':
                if not OPENPYXL_AVAILABLE:
                    messagebox.showerror("Ошибка", "Модуль openpyxl не установлен. Установите его для экспорта в Excel.\nСохранение в CSV.")
                    return
                wb = Workbook()
                ws = wb.active
                ws.title = "Коды"
                for i, line in enumerate(lines, start=1):
                    ws.cell(row=i, column=1, value=line)
                wb.save(file_path)
                messagebox.showinfo("Успех", f"Экспорт в Excel выполнен:\n{file_path}")
            else:
                messagebox.showerror("Ошибка", "Неподдерживаемое расширение. Используйте .csv или .xlsx")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось экспортировать:\n{e}")

    def send_by_email(self, event=None):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет сгенерированных кодов для отправки.")
            return
        encoded_body = urllib.parse.quote(content)
        subject = urllib.parse.quote("Сгенерированные коды")
        webbrowser.open(f"mailto:?subject={subject}&body={encoded_body}")

    def copy_to_clipboard(self, event=None):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет текста для копирования.")
            return
        self.clipboard_clear()
        self.clipboard_append(content)
        self.update()
        messagebox.showinfo("Копирование", "Текст скопирован в буфер обмена.")

    def clear_output(self, event=None):
        self.output_text.delete(1.0, tk.END)

    def quit_app(self, event=None):
        self.destroy()

    def show_about(self):
        self.notebook.select(self.about_tab_index)

    # --------------------------------------------------------------------------
    # Горячие клавиши
    # --------------------------------------------------------------------------
    def bind_shortcuts(self):
        self.bind_all('<Control-g>', self.generate_codes)
        self.bind_all('<Control-c>', self.copy_to_clipboard)
        self.bind_all('<Control-s>', self.save_result_to_file)
        self.bind_all('<Control-e>', self.send_by_email)
        self.bind_all('<Control-t>', self.save_current_as_template)
        self.bind_all('<Control-q>', self.quit_app)
        self.bind_all('<Control-x>', self.clear_output)

    # --------------------------------------------------------------------------
    # Обновление состояния виджетов (активность)
    # --------------------------------------------------------------------------
    def update_widgets_state(self):
        if self.order_mode.get() == "random":
            self.length_entry.config(state="normal")
            self.template_entry.config(state="disabled")
        else:
            self.length_entry.config(state="disabled")
            self.template_entry.config(state="normal")

        if self.use_hyphens.get():
            self.interval_entry.config(state="normal")
        else:
            self.interval_entry.config(state="disabled")

        if self.letters_mode.get() == "lang":
            for rb in self.lang_radiobuttons:
                rb.config(state="normal")
            self.custom_entry.config(state="disabled")
        else:
            for rb in self.lang_radiobuttons:
                rb.config(state="disabled")
            self.custom_entry.config(state="normal")

        if self.use_digits.get():
            if self.digits_mode.get() == "custom":
                self.custom_digits_entry.config(state="normal")
            else:
                self.custom_digits_entry.config(state="disabled")
            for rb in self.digits_radiobuttons:
                rb.config(state="normal")
        else:
            for rb in self.digits_radiobuttons:
                rb.config(state="disabled")
            self.custom_digits_entry.config(state="disabled")

    # --------------------------------------------------------------------------
    # Построение интерфейса
    # --------------------------------------------------------------------------
    def create_menu(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Файл", menu=file_menu)
        file_menu.add_command(label="Сохранить результат", accelerator="Ctrl+S", command=self.save_result_to_file)
        file_menu.add_command(label="Экспорт в CSV/Excel", command=self.export_csv_excel)
        file_menu.add_command(label="Отправить по email", accelerator="Ctrl+E", command=self.send_by_email)
        file_menu.add_separator()
        file_menu.add_command(label="Выход", accelerator="Ctrl+Q", command=self.quit_app)

        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Правка", menu=edit_menu)
        edit_menu.add_command(label="Копировать в буфер", accelerator="Ctrl+C", command=self.copy_to_clipboard)
        edit_menu.add_command(label="Очистить результат", accelerator="Ctrl+X", command=self.clear_output)

        template_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Шаблоны", menu=template_menu)
        template_menu.add_command(label="Сохранить текущие настройки как шаблон", accelerator="Ctrl+T", command=self.save_current_as_template)
        template_menu.add_command(label="Импортировать шаблон", command=self.import_template)
        template_menu.add_command(label="Экспортировать шаблон", command=self.export_template)

    def create_widgets(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.create_main_tab()
        self.create_templates_tab()
        self.about_tab_index = self.create_about_tab()

    def create_main_tab(self):
        main_tab = ttk.Frame(self.notebook)
        self.notebook.add(main_tab, text="Главная")

        canvas = tk.Canvas(main_tab)
        scrollbar = ttk.Scrollbar(main_tab, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Рамка символов
        chars_frame = ttk.LabelFrame(scrollable_frame, text="Используемые символы")
        chars_frame.pack(fill=tk.X, pady=5, padx=5)

        ttk.Checkbutton(chars_frame, text="Цифры (0-9)", variable=self.use_digits,
                        command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)
        ttk.Checkbutton(chars_frame, text="Буквы (Заглавные)", variable=self.use_letters,
                        command=self.update_widgets_state).grid(row=0, column=1, sticky=tk.W, padx=10, pady=5)
        ttk.Checkbutton(chars_frame, text="Буквы (Маленькие)", variable=self.use_lowercase,
                        command=self.update_widgets_state).grid(row=0, column=2, sticky=tk.W, padx=10, pady=5)

        digits_subframe = ttk.Frame(chars_frame)
        digits_subframe.grid(row=1, column=0, columnspan=3, sticky=tk.W, padx=20, pady=5)
        ttk.Label(digits_subframe, text="Настройка цифр:").pack(side=tk.LEFT, padx=(0,10))
        rb_std = ttk.Radiobutton(digits_subframe, text="Циферный (0-9)", variable=self.digits_mode,
                                 value="standard", command=self.update_widgets_state)
        rb_custom = ttk.Radiobutton(digits_subframe, text="Уникальный", variable=self.digits_mode,
                                    value="custom", command=self.update_widgets_state)
        rb_std.pack(side=tk.LEFT, padx=5)
        rb_custom.pack(side=tk.LEFT, padx=5)
        self.custom_digits_entry = ttk.Entry(digits_subframe, textvariable=self.custom_digits, width=12)
        self.custom_digits_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(digits_subframe, text="(только цифры)").pack(side=tk.LEFT)
        self.digits_radiobuttons = [rb_std, rb_custom]

        # Порядок символов
        order_frame = ttk.LabelFrame(scrollable_frame, text="Порядок символов")
        order_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Radiobutton(order_frame, text="Рандомный (длина кода)", variable=self.order_mode,
                        value="random", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(order_frame, text="Уникальный (шаблон Б/Ц)", variable=self.order_mode,
                        value="unique", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        length_frame = ttk.Frame(order_frame)
        length_frame.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(length_frame, text="Длина кода:").pack(side=tk.LEFT)
        self.length_entry = ttk.Entry(length_frame, textvariable=self.code_length, width=6)
        self.length_entry.pack(side=tk.LEFT, padx=5)

        template_frame = ttk.Frame(order_frame)
        template_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(template_frame, text="Шаблон (Б=буква, Ц=цифра):").pack(side=tk.LEFT)
        self.template_entry = ttk.Entry(template_frame, textvariable=self.template_str, width=20)
        self.template_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(template_frame, text="Пример: ББЦЦЦ").pack(side=tk.LEFT, padx=5)

        # Дефисы
        hyphens_frame = ttk.LabelFrame(scrollable_frame, text="Дефисы")
        hyphens_frame.pack(fill=tk.X, pady=5, padx=5)
        self.hyphens_check = ttk.Checkbutton(hyphens_frame, text="Использовать дефисы",
                                             variable=self.use_hyphens, command=self.update_widgets_state)
        self.hyphens_check.pack(side=tk.LEFT, padx=10, pady=5)
        interval_frame = ttk.Frame(hyphens_frame)
        interval_frame.pack(side=tk.LEFT, padx=10, pady=5)
        ttk.Label(interval_frame, text="Через каждые N символов:").pack(side=tk.LEFT)
        self.interval_entry = ttk.Entry(interval_frame, textvariable=self.hyphen_interval, width=5)
        self.interval_entry.pack(side=tk.LEFT, padx=5)

        # Набор букв
        letters_frame = ttk.LabelFrame(scrollable_frame, text="Набор букв")
        letters_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Radiobutton(letters_frame, text="Язычный", variable=self.letters_mode,
                        value="lang", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(letters_frame, text="Уникальный (пользовательский)", variable=self.letters_mode,
                        value="custom", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        lang_subframe = ttk.Frame(letters_frame)
        lang_subframe.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        rb1 = ttk.Radiobutton(lang_subframe, text="Русский", variable=self.lang_choice, value="russian")
        rb2 = ttk.Radiobutton(lang_subframe, text="Английский", variable=self.lang_choice, value="english")
        rb1.pack(side=tk.LEFT, padx=5)
        rb2.pack(side=tk.LEFT, padx=5)
        self.lang_radiobuttons = [rb1, rb2]

        custom_frame = ttk.Frame(letters_frame)
        custom_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(custom_frame, text="Набор букв:").pack(side=tk.LEFT)
        self.custom_entry = ttk.Entry(custom_frame, textvariable=self.custom_letters, width=20)
        self.custom_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(custom_frame, text="(только заглавные, пример: ABCXYZ)").pack(side=tk.LEFT, padx=5)

        # Предпросмотр
        preview_frame = ttk.LabelFrame(scrollable_frame, text="Предпросмотр (один код)")
        preview_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Label(preview_frame, text="Код:").pack(side=tk.LEFT, padx=5)
        self.preview_value = ttk.Entry(preview_frame, state="readonly", width=40)
        self.preview_value.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)

        # Количество кодов и кнопки
        control_frame = ttk.Frame(scrollable_frame)
        control_frame.pack(fill=tk.X, pady=10, padx=5)
        ttk.Label(control_frame, text="Количество кодов:").pack(side=tk.LEFT, padx=5)
        self.num_codes_entry = ttk.Entry(control_frame, textvariable=self.num_codes, width=6)
        self.num_codes_entry.pack(side=tk.LEFT, padx=5)
        self.generate_btn = ttk.Button(control_frame, text="Сгенерировать", command=self.generate_codes)
        self.generate_btn.pack(side=tk.LEFT, padx=10)
        self.save_template_btn = ttk.Button(control_frame, text="Сохранить в шаблон", command=self.save_current_as_template)
        self.save_template_btn.pack(side=tk.LEFT, padx=10)

        # Поле вывода
        output_frame = ttk.LabelFrame(scrollable_frame, text="Результат")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=5, padx=5)
        self.output_text = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD, height=12)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        copy_btn = ttk.Button(output_frame, text="Скопировать в буфер", command=self.copy_to_clipboard)
        copy_btn.pack(pady=(0, 5))

    def create_templates_tab(self):
        templates_tab = ttk.Frame(self.notebook)
        self.notebook.add(templates_tab, text="Шаблоны")

        list_frame = ttk.LabelFrame(templates_tab, text="Сохранённые шаблоны")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.templates_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set)
        self.templates_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.templates_listbox.yview)
        self.update_templates_list()

        btn_frame = ttk.Frame(templates_tab)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(btn_frame, text="Использовать шаблон", command=self._on_use_template).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Удалить шаблон", command=self._on_delete_template).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Экспортировать шаблон", command=self.export_template).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Показать настройки", command=self.show_template_settings).pack(side=tk.LEFT, padx=5)

    def _on_use_template(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон из списка.")
            return
        name = self.templates_listbox.get(selection[0])
        self.apply_template(name)

    def _on_delete_template(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон для удаления.")
            return
        name = self.templates_listbox.get(selection[0])
        if messagebox.askyesno("Подтверждение", f"Удалить шаблон '{name}'?"):
            self.delete_template(name)

    def show_template_settings(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон из списка.")
            return
        name = self.templates_listbox.get(selection[0])
        settings = self.templates.get(name, {})
        if not settings:
            messagebox.showerror("Ошибка", f"Не удалось загрузить настройки шаблона '{name}'.")
            return

        win = tk.Toplevel(self)
        win.title(f"Настройки шаблона: {name}")
        win.geometry("550x550")
        win.resizable(True, True)

        text_frame = ttk.Frame(win)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar = ttk.Scrollbar(text_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        text_widget = tk.Text(text_frame, wrap=tk.WORD, yscrollcommand=scrollbar.set,
                              font=("Courier", 10), padx=5, pady=5)
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=text_widget.yview)

        lines = []
        lines.append(f"Имя шаблона: {name}\n")
        use_digits = settings.get("use_digits", True)
        use_letters = settings.get("use_letters", True)
        use_lowercase = settings.get("use_lowercase", False)
        lines.append(f"Использовать цифры: {'Да' if use_digits else 'Нет'}")
        if use_digits:
            digits_mode = settings.get("digits_mode", "standard")
            if digits_mode == "standard":
                lines.append("  Цифры: стандартный набор (0-9)")
            else:
                custom_digits = settings.get("custom_digits", "")
                lines.append(f"  Цифры: уникальный набор = {custom_digits if custom_digits else '(не задан)'}")
        lines.append(f"Использовать буквы (заглавные): {'Да' if use_letters else 'Нет'}")
        lines.append(f"Использовать буквы (строчные): {'Да' if use_lowercase else 'Нет'}\n")
        order_mode = settings.get("order_mode", "random")
        if order_mode == "random":
            random_length = settings.get("random_length", 8)
            lines.append(f"Порядок: Рандомный, длина = {random_length}")
        else:
            unique_pattern = settings.get("unique_pattern", "")
            lines.append(f"Порядок: Уникальный, шаблон = {unique_pattern if unique_pattern else '(не задан)'}")
        lines.append("")
        use_hyphens = settings.get("use_hyphens", False)
        if use_hyphens:
            interval = settings.get("hyphen_interval", 3)
            lines.append(f"Дефисы: Да, через каждые {interval} символов")
        else:
            lines.append("Дефисы: Нет")
        lines.append("")
        letters_mode = settings.get("letters_mode", "lang")
        if letters_mode == "lang":
            lang = settings.get("letters_language", "english")
            lang_text = "Русский" if lang == "russian" else "Английский"
            lines.append(f"Буквы: Язычный, {lang_text}")
        else:
            custom = settings.get("custom_letters", "")
            lines.append(f"Буквы: Уникальный, набор = {custom if custom else '(не задан)'}")
        lines.append("")
        num_codes = settings.get("num_codes", 1)
        lines.append(f"Количество кодов: {num_codes}")

        text_widget.insert(tk.END, "\n".join(lines))
        text_widget.config(state=tk.DISABLED)

        btn_frame = ttk.Frame(win)
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Button(btn_frame, text="Закрыть", command=win.destroy).pack()

    def create_about_tab(self):
        about_tab = ttk.Frame(self.notebook)
        self.notebook.add(about_tab, text="О программе")
        info_text = (
            "Генератор кодов\n"
            "Версия: 1.1.3\n"
            "Автор: Royzloy\n\n"
            "Описание:\n"
            "Приложение позволяет генерировать коды (строки) по заданным правилам:\n"
            "• Использование цифр (стандартный или уникальный набор), заглавных и строчных букв.\n"
            "• Два режима порядка символов: случайный (заданной длины) или уникальный (по шаблону Б/Ц).\n"
            "• Возможность вставки дефисов через заданный интервал.\n"
            "• Выбор букв: язычный (русский или английский алфавит) или уникальный пользовательский набор.\n"
            "• Генерация нескольких кодов за раз.\n\n"
            "Нововведения версии 1.1.3:\n"
            "• Предпросмотр кода в реальном времени\n"
            "• Горячие клавиши (Ctrl+G, Ctrl+C, Ctrl+S, Ctrl+E, Ctrl+T, Ctrl+Q, Ctrl+X)\n"
            "• Экспорт в CSV/Excel\n"
            "• Меню вместо вкладки «Файл»\n"
            "• Импорт/экспорт шаблонов в формате .gcs\n"
        )
        text_widget = tk.Text(about_tab, wrap=tk.WORD, font=("Arial", 10), padx=10, pady=10)
        text_widget.insert(tk.END, info_text)
        text_widget.config(state=tk.DISABLED)
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        return self.notebook.index("end") - 1


if __name__ == "__main__":
    app = CodeGeneratorApp()
    app.mainloop()