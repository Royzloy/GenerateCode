import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, scrolledtext, filedialog
import random
import re
import json
import os
import webbrowser
import urllib.parse

class CodeGeneratorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Генератор кодов")
        self.geometry("750x850")
        self.resizable(True, True)

        # Переменные для настроек генерации
        self.use_digits = tk.BooleanVar(value=True)
        self.use_letters = tk.BooleanVar(value=True)
        self.use_lowercase = tk.BooleanVar(value=False)

        # Настройки цифр (НОВЫЕ)
        self.digits_mode = tk.StringVar(value="standard")  # "standard" или "custom"
        self.custom_digits = tk.StringVar(value="")

        self.order_mode = tk.StringVar(value="random")
        self.code_length = tk.IntVar(value=8)
        self.template_str = tk.StringVar(value="")
        self.use_hyphens = tk.BooleanVar(value=False)
        self.hyphen_interval = tk.IntVar(value=3)
        self.letters_mode = tk.StringVar(value="lang")
        self.lang_choice = tk.StringVar(value="english")
        self.custom_letters = tk.StringVar(value="")
        self.num_codes = tk.IntVar(value=1)

        # Файл шаблонов
        self.templates_file = "templates.json"
        self.templates = {}
        self.load_templates()

        # Создание интерфейса
        self.create_widgets()
        self.update_widgets_state()

    # --------------------------------------------------------------------------
    # Загрузка и сохранение шаблонов
    # --------------------------------------------------------------------------
    def load_templates(self):
        if os.path.exists(self.templates_file):
            try:
                with open(self.templates_file, 'r', encoding='utf-8') as f:
                    self.templates = json.load(f)
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить шаблоны:\n{e}")
                self.templates = {}
        else:
            self.templates = {}

    def save_templates(self):
        try:
            with open(self.templates_file, 'w', encoding='utf-8') as f:
                json.dump(self.templates, f, ensure_ascii=False, indent=2)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить шаблоны:\n{e}")

    def get_current_settings(self):
        settings = {
            "use_digits": self.use_digits.get(),
            "use_letters": self.use_letters.get(),
            "use_lowercase": self.use_lowercase.get(),
            "digits_mode": self.digits_mode.get(),
            "custom_digits": self.custom_digits.get().strip(),
            "order_mode": self.order_mode.get(),
            "random_length": self.code_length.get(),
            "unique_pattern": self.template_str.get().strip(),
            "use_hyphens": self.use_hyphens.get(),
            "hyphen_interval": self.hyphen_interval.get(),
            "letters_mode": self.letters_mode.get(),
            "letters_language": self.lang_choice.get(),
            "custom_letters": self.custom_letters.get().strip().upper(),
            "num_codes": self.num_codes.get()
        }
        return settings

    def apply_settings(self, settings):
        self.use_digits.set(settings.get("use_digits", True))
        self.use_letters.set(settings.get("use_letters", True))
        self.use_lowercase.set(settings.get("use_lowercase", False))
        self.digits_mode.set(settings.get("digits_mode", "standard"))
        self.custom_digits.set(settings.get("custom_digits", ""))
        self.order_mode.set(settings.get("order_mode", "random"))
        self.code_length.set(settings.get("random_length", 8))
        self.template_str.set(settings.get("unique_pattern", ""))
        self.use_hyphens.set(settings.get("use_hyphens", False))
        self.hyphen_interval.set(settings.get("hyphen_interval", 3))
        self.letters_mode.set(settings.get("letters_mode", "lang"))
        self.lang_choice.set(settings.get("letters_language", "english"))
        self.custom_letters.set(settings.get("custom_letters", ""))
        self.num_codes.set(settings.get("num_codes", 1))

        self.update_widgets_state()

    def save_current_as_template(self):
        name = simpledialog.askstring("Сохранить шаблон", "Введите имя шаблона:")
        if not name:
            return
        if name in self.templates:
            overwrite = messagebox.askyesno("Подтверждение",
                                            f"Шаблон с именем '{name}' уже существует. Перезаписать?")
            if not overwrite:
                return
        self.templates[name] = self.get_current_settings()
        self.save_templates()
        if hasattr(self, 'templates_listbox'):
            self.update_templates_list()
        messagebox.showinfo("Успех", f"Шаблон '{name}' сохранён.")

    def delete_template(self, name):
        if name in self.templates:
            del self.templates[name]
            self.save_templates()
            self.update_templates_list()
            messagebox.showinfo("Успех", f"Шаблон '{name}' удалён.")

    def apply_template(self, name):
        if name not in self.templates:
            messagebox.showerror("Ошибка", f"Шаблон '{name}' не найден.")
            return
        settings = self.templates[name]
        self.apply_settings(settings)
        self.notebook.select(0)
        messagebox.showinfo("Шаблон применён", f"Настройки из шаблона '{name}' загружены.")

    def update_templates_list(self):
        if hasattr(self, 'templates_listbox'):
            self.templates_listbox.delete(0, tk.END)
            for name in sorted(self.templates.keys()):
                self.templates_listbox.insert(tk.END, name)

    # --------------------------------------------------------------------------
    # Просмотр настроек шаблона (обновлённый)
    # --------------------------------------------------------------------------
    def show_template_settings(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон из списка.")
            return
        name = self.templates_listbox.get(selection[0])
        settings = self.templates.get(name, {})
        if not settings:
            messagebox.showerror("Ошибка", f"Не удалось загрузить настройки шаблона '{name}'.")
            return

        win = tk.Toplevel(self)
        win.title(f"Настройки шаблона: {name}")
        win.geometry("550x550")
        win.resizable(True, True)

        text_frame = ttk.Frame(win)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar = ttk.Scrollbar(text_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        text_widget = tk.Text(text_frame, wrap=tk.WORD, yscrollcommand=scrollbar.set,
                              font=("Courier", 10), padx=5, pady=5)
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=text_widget.yview)

        lines = []
        lines.append(f"Имя шаблона: {name}")
        lines.append("")
        use_digits = settings.get("use_digits", True)
        use_letters = settings.get("use_letters", True)
        use_lowercase = settings.get("use_lowercase", False)
        lines.append(f"Использовать цифры: {'Да' if use_digits else 'Нет'}")
        if use_digits:
            digits_mode = settings.get("digits_mode", "standard")
            if digits_mode == "standard":
                lines.append("  Цифры: стандартный набор (0-9)")
            else:
                custom_digits = settings.get("custom_digits", "")
                lines.append(f"  Цифры: уникальный набор = {custom_digits if custom_digits else '(не задан)'}")
        lines.append(f"Использовать буквы (заглавные): {'Да' if use_letters else 'Нет'}")
        lines.append(f"Использовать буквы (строчные): {'Да' if use_lowercase else 'Нет'}")
        lines.append("")

        order_mode = settings.get("order_mode", "random")
        if order_mode == "random":
            random_length = settings.get("random_length", 8)
            lines.append(f"Порядок: Рандомный, длина = {random_length}")
        else:
            unique_pattern = settings.get("unique_pattern", "")
            lines.append(f"Порядок: Уникальный, шаблон = {unique_pattern if unique_pattern else '(не задан)'}")
        lines.append("")

        use_hyphens = settings.get("use_hyphens", False)
        if use_hyphens:
            interval = settings.get("hyphen_interval", 3)
            lines.append(f"Дефисы: Да, через каждые {interval} символов")
        else:
            lines.append("Дефисы: Нет")
        lines.append("")

        letters_mode = settings.get("letters_mode", "lang")
        if letters_mode == "lang":
            lang = settings.get("letters_language", "english")
            lang_text = "Русский" if lang == "russian" else "Английский"
            lines.append(f"Буквы: Язычный, {lang_text}")
        else:
            custom = settings.get("custom_letters", "")
            lines.append(f"Буквы: Уникальный, набор = {custom if custom else '(не задан)'}")
        lines.append("")

        num_codes = settings.get("num_codes", 1)
        lines.append(f"Количество кодов: {num_codes}")

        text_widget.insert(tk.END, "\n".join(lines))
        text_widget.config(state=tk.DISABLED)

        btn_frame = ttk.Frame(win)
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        close_btn = ttk.Button(btn_frame, text="Закрыть", command=win.destroy)
        close_btn.pack()

    # --------------------------------------------------------------------------
    # Логика получения символов (цифры + буквы)
    # --------------------------------------------------------------------------
    def get_digits_pool(self):
        """Возвращает строку доступных цифр согласно настройкам."""
        if not self.use_digits.get():
            return ""
        if self.digits_mode.get() == "standard":
            return "0123456789"
        else:  # custom
            custom = self.custom_digits.get().strip()
            # Проверка будет выполнена при генерации
            return custom

    def get_letter_pools(self):
        """Возвращает кортеж (uppercase_pool, lowercase_pool)."""
        upper_pool = ""
        lower_pool = ""
        if self.use_letters.get():
            if self.letters_mode.get() == "lang":
                if self.lang_choice.get() == "russian":
                    upper_pool = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
                else:
                    upper_pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            else:  # custom
                upper_pool = self.custom_letters.get().strip().upper()
        if self.use_lowercase.get():
            if self.letters_mode.get() == "lang":
                base = self.get_letter_pools()[0] if self.use_letters.get() else (
                    "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ" if self.lang_choice.get() == "russian" else "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                )
                lower_pool = base.lower()
            else:  # custom
                base = self.custom_letters.get().strip()
                lower_pool = ''.join(ch.lower() for ch in base if ch.isalpha())
        return upper_pool, lower_pool

    def generate_random_code(self, length, digits_pool, upper_pool, lower_pool):
        pool = []
        if digits_pool:
            pool.extend(digits_pool)
        if upper_pool:
            pool.extend(upper_pool)
        if lower_pool:
            pool.extend(lower_pool)
        if not pool:
            raise ValueError("Нет доступных символов для генерации")
        return ''.join(random.choice(pool) for _ in range(length))

    def generate_unique_code(self, template, digits_pool, upper_pool, lower_pool):
        code_chars = []
        for ch in template:
            if ch == 'Б':
                available = []
                if upper_pool:
                    available.extend(upper_pool)
                if lower_pool:
                    available.extend(lower_pool)
                if not available:
                    raise ValueError("Нет доступных букв для заполнения шаблона")
                code_chars.append(random.choice(available))
            elif ch == 'Ц':
                if not digits_pool:
                    raise ValueError("Цифры не разрешены, но шаблон требует цифру")
                code_chars.append(random.choice(digits_pool))
            else:
                raise ValueError(f"Недопустимый символ в шаблоне: {ch}")
        return ''.join(code_chars)

    def insert_hyphens(self, code, interval):
        if interval <= 0:
            return code
        parts = [code[i:i+interval] for i in range(0, len(code), interval)]
        return '-'.join(parts)

    def update_widgets_state(self):
        # Порядок символов
        if self.order_mode.get() == "random":
            self.length_entry.config(state="normal")
            self.template_entry.config(state="disabled")
        else:
            self.length_entry.config(state="disabled")
            self.template_entry.config(state="normal")

        # Дефисы
        if self.use_hyphens.get():
            self.interval_entry.config(state="normal")
        else:
            self.interval_entry.config(state="disabled")

        # Буквы (язычный/уникальный)
        if self.letters_mode.get() == "lang":
            for rb in self.lang_radiobuttons:
                rb.config(state="normal")
            self.custom_entry.config(state="disabled")
        else:
            for rb in self.lang_radiobuttons:
                rb.config(state="disabled")
            self.custom_entry.config(state="normal")

        # Цифры: уникальный режим активирует поле ввода
        if self.use_digits.get():
            if self.digits_mode.get() == "custom":
                self.custom_digits_entry.config(state="normal")
            else:
                self.custom_digits_entry.config(state="disabled")
            # Радиокнопки всегда активны, если цифры включены
            for rb in self.digits_radiobuttons:
                rb.config(state="normal")
        else:
            # Если цифры отключены, блокируем всю секцию выбора цифр
            for rb in self.digits_radiobuttons:
                rb.config(state="disabled")
            self.custom_digits_entry.config(state="disabled")

    # --------------------------------------------------------------------------
    # Генерация кодов (основной метод)
    # --------------------------------------------------------------------------
    def generate_codes(self):
        self.output_text.delete(1.0, tk.END)

        digits_enabled = self.use_digits.get()
        letters_upper_enabled = self.use_letters.get()
        letters_lower_enabled = self.use_lowercase.get()
        if not digits_enabled and not letters_upper_enabled and not letters_lower_enabled:
            messagebox.showerror("Ошибка", "Необходимо выбрать хотя бы один тип символов: цифры, заглавные буквы или строчные буквы.")
            return

        try:
            num = self.num_codes.get()
            if num <= 0:
                raise ValueError
        except:
            messagebox.showerror("Ошибка", "Количество кодов должно быть положительным целым числом.")
            return

        # Получение пула цифр
        digits_pool = ""
        if digits_enabled:
            if self.digits_mode.get() == "standard":
                digits_pool = "0123456789"
            else:  # custom
                custom_digits = self.custom_digits.get().strip()
                if not custom_digits:
                    messagebox.showerror("Ошибка", "В режиме 'Уникальные цифры' необходимо указать набор цифр.")
                    return
                if not re.fullmatch(r'[0-9]+', custom_digits):
                    messagebox.showerror("Ошибка", "Набор уникальных цифр может содержать только цифры (0-9).")
                    return
                digits_pool = custom_digits

        # Получение буквенных пулов
        upper_pool, lower_pool = "", ""
        if letters_upper_enabled or letters_lower_enabled:
            if self.letters_mode.get() == "lang":
                upper_pool, lower_pool = self.get_letter_pools()
            else:  # custom
                custom_letters = self.custom_letters.get().strip()
                if not custom_letters:
                    messagebox.showerror("Ошибка", "В режиме 'Уникальный набор букв' необходимо указать набор букв.")
                    return
                if letters_upper_enabled:
                    upper_pool = custom_letters.upper()
                if letters_lower_enabled:
                    lower_pool = ''.join(ch.lower() for ch in custom_letters)

        mode = self.order_mode.get()
        if mode == "random":
            try:
                length = self.code_length.get()
                if length <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Длина кода должна быть положительным целым числом.")
                return
        else:
            template = self.template_str.get().strip().upper()
            if not template:
                messagebox.showerror("Ошибка", "Шаблон не может быть пустым.")
                return
            if not re.fullmatch(r'[БЦ]+', template):
                messagebox.showerror("Ошибка", "Шаблон может содержать только символы 'Б' и 'Ц'.")
                return
            if 'Б' in template and not (letters_upper_enabled or letters_lower_enabled):
                messagebox.showerror("Ошибка", "Шаблон содержит буквы ('Б'), но использование букв отключено.")
                return
            if 'Ц' in template and not digits_enabled:
                messagebox.showerror("Ошибка", "Шаблон содержит цифры ('Ц'), но использование цифр отключено.")
                return
            length = len(template)

        use_hyphens = self.use_hyphens.get()
        interval = None
        if use_hyphens:
            try:
                interval = self.hyphen_interval.get()
                if interval <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Интервал для дефисов должен быть положительным целым числом.")
                return

        codes = []
        for _ in range(num):
            try:
                if mode == "random":
                    code = self.generate_random_code(length, digits_pool, upper_pool, lower_pool)
                else:
                    template = self.template_str.get().strip().upper()
                    code = self.generate_unique_code(template, digits_pool, upper_pool, lower_pool)
                if use_hyphens:
                    code = self.insert_hyphens(code, interval)
                codes.append(code)
            except Exception as e:
                messagebox.showerror("Ошибка генерации", str(e))
                return

        self.output_text.insert(1.0, "\n".join(codes))

    # --------------------------------------------------------------------------
    # Функции вкладки "Файл"
    # --------------------------------------------------------------------------
    def save_result_to_file(self):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет сгенерированных кодов для сохранения.")
            return
        file_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")],
            title="Сохранить результат"
        )
        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                messagebox.showinfo("Успех", f"Результат сохранён в:\n{file_path}")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось сохранить файл:\n{e}")

    def send_by_email(self):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет сгенерированных кодов для отправки.")
            return
        encoded_body = urllib.parse.quote(content)
        subject = urllib.parse.quote("Сгенерированные коды")
        webbrowser.open(f"mailto:?subject={subject}&body={encoded_body}")

    def copy_to_clipboard(self):
        content = self.output_text.get(1.0, tk.END).strip()
        if not content:
            messagebox.showwarning("Предупреждение", "Нет текста для копирования.")
            return
        self.clipboard_clear()
        self.clipboard_append(content)
        self.update()
        messagebox.showinfo("Копирование", "Текст скопирован в буфер обмена.")

    def quit_app(self):
        self.destroy()

    # --------------------------------------------------------------------------
    # Построение интерфейса
    # --------------------------------------------------------------------------
    def create_widgets(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.create_main_tab()
        self.create_file_tab()
        self.create_templates_tab()
        self.create_about_tab()

    def create_main_tab(self):
        main_tab = ttk.Frame(self.notebook)
        self.notebook.add(main_tab, text="Главная")

        canvas = tk.Canvas(main_tab)
        scrollbar = ttk.Scrollbar(main_tab, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # 1. Рамка символов (цифры + буквы)
        chars_frame = ttk.LabelFrame(scrollable_frame, text="Используемые символы")
        chars_frame.pack(fill=tk.X, pady=5, padx=5)

        # Чекбоксы
        ttk.Checkbutton(chars_frame, text="Цифры (0-9)", variable=self.use_digits,
                        command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=10, pady=5)
        ttk.Checkbutton(chars_frame, text="Буквы (Заглавные)", variable=self.use_letters,
                        command=self.update_widgets_state).grid(row=0, column=1, sticky=tk.W, padx=10, pady=5)
        ttk.Checkbutton(chars_frame, text="Буквы (Маленькие)", variable=self.use_lowercase,
                        command=self.update_widgets_state).grid(row=0, column=2, sticky=tk.W, padx=10, pady=5)

        # Подрамка для выбора набора цифр (новая)
        digits_subframe = ttk.Frame(chars_frame)
        digits_subframe.grid(row=1, column=0, columnspan=3, sticky=tk.W, padx=20, pady=5)
        ttk.Label(digits_subframe, text="Настройка цифр:").pack(side=tk.LEFT, padx=(0,10))
        rb_std = ttk.Radiobutton(digits_subframe, text="Циферный (0-9)", variable=self.digits_mode,
                                 value="standard", command=self.update_widgets_state)
        rb_custom = ttk.Radiobutton(digits_subframe, text="Уникальный", variable=self.digits_mode,
                                    value="custom", command=self.update_widgets_state)
        rb_std.pack(side=tk.LEFT, padx=5)
        rb_custom.pack(side=tk.LEFT, padx=5)
        self.custom_digits_entry = ttk.Entry(digits_subframe, textvariable=self.custom_digits, width=12)
        self.custom_digits_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(digits_subframe, text="(только цифры)").pack(side=tk.LEFT)
        self.digits_radiobuttons = [rb_std, rb_custom]

        # 2. Порядок символов (без изменений)
        order_frame = ttk.LabelFrame(scrollable_frame, text="Порядок символов")
        order_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Radiobutton(order_frame, text="Рандомный (длина кода)", variable=self.order_mode,
                        value="random", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(order_frame, text="Уникальный (шаблон Б/Ц)", variable=self.order_mode,
                        value="unique", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        length_frame = ttk.Frame(order_frame)
        length_frame.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(length_frame, text="Длина кода:").pack(side=tk.LEFT)
        self.length_entry = ttk.Entry(length_frame, textvariable=self.code_length, width=6)
        self.length_entry.pack(side=tk.LEFT, padx=5)

        template_frame = ttk.Frame(order_frame)
        template_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(template_frame, text="Шаблон (Б=буква, Ц=цифра):").pack(side=tk.LEFT)
        self.template_entry = ttk.Entry(template_frame, textvariable=self.template_str, width=20)
        self.template_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(template_frame, text="Пример: ББЦЦЦ").pack(side=tk.LEFT, padx=5)

        # 3. Дефисы
        hyphens_frame = ttk.LabelFrame(scrollable_frame, text="Дефисы")
        hyphens_frame.pack(fill=tk.X, pady=5, padx=5)
        self.hyphens_check = ttk.Checkbutton(hyphens_frame, text="Использовать дефисы",
                                             variable=self.use_hyphens, command=self.update_widgets_state)
        self.hyphens_check.pack(side=tk.LEFT, padx=10, pady=5)
        interval_frame = ttk.Frame(hyphens_frame)
        interval_frame.pack(side=tk.LEFT, padx=10, pady=5)
        ttk.Label(interval_frame, text="Через каждые N символов:").pack(side=tk.LEFT)
        self.interval_entry = ttk.Entry(interval_frame, textvariable=self.hyphen_interval, width=5)
        self.interval_entry.pack(side=tk.LEFT, padx=5)

        # 4. Набор букв (без изменений)
        letters_frame = ttk.LabelFrame(scrollable_frame, text="Набор букв")
        letters_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Radiobutton(letters_frame, text="Язычный", variable=self.letters_mode,
                        value="lang", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(letters_frame, text="Уникальный (пользовательский)", variable=self.letters_mode,
                        value="custom", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        lang_subframe = ttk.Frame(letters_frame)
        lang_subframe.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        rb1 = ttk.Radiobutton(lang_subframe, text="Русский", variable=self.lang_choice, value="russian")
        rb2 = ttk.Radiobutton(lang_subframe, text="Английский", variable=self.lang_choice, value="english")
        rb1.pack(side=tk.LEFT, padx=5)
        rb2.pack(side=tk.LEFT, padx=5)
        self.lang_radiobuttons = [rb1, rb2]

        custom_frame = ttk.Frame(letters_frame)
        custom_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(custom_frame, text="Набор букв:").pack(side=tk.LEFT)
        self.custom_entry = ttk.Entry(custom_frame, textvariable=self.custom_letters, width=20)
        self.custom_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(custom_frame, text="(только заглавные, пример: ABCXYZ)").pack(side=tk.LEFT, padx=5)

        # 5. Количество кодов и кнопки
        control_frame = ttk.Frame(scrollable_frame)
        control_frame.pack(fill=tk.X, pady=10, padx=5)
        ttk.Label(control_frame, text="Количество кодов:").pack(side=tk.LEFT, padx=5)
        self.num_codes_entry = ttk.Entry(control_frame, textvariable=self.num_codes, width=6)
        self.num_codes_entry.pack(side=tk.LEFT, padx=5)
        self.generate_btn = ttk.Button(control_frame, text="Сгенерировать", command=self.generate_codes)
        self.generate_btn.pack(side=tk.LEFT, padx=10)
        self.save_template_btn = ttk.Button(control_frame, text="Сохранить в шаблон", command=self.save_current_as_template)
        self.save_template_btn.pack(side=tk.LEFT, padx=10)

        # 6. Поле вывода
        output_frame = ttk.LabelFrame(scrollable_frame, text="Результат")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=5, padx=5)
        self.output_text = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD, height=12)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 7. Кнопка копирования
        copy_btn = ttk.Button(output_frame, text="Скопировать в буфер", command=self.copy_to_clipboard)
        copy_btn.pack(pady=(0, 5))

    def create_file_tab(self):
        file_tab = ttk.Frame(self.notebook)
        self.notebook.add(file_tab, text="Файл")
        frame = ttk.Frame(file_tab)
        frame.pack(expand=True, fill=tk.BOTH, padx=20, pady=20)
        ttk.Button(frame, text="Сохранить результат", command=self.save_result_to_file, width=30).pack(pady=10)
        ttk.Button(frame, text="Отправить по email", command=self.send_by_email, width=30).pack(pady=10)
        ttk.Button(frame, text="Отмена (Закрыть приложение)", command=self.quit_app, width=30).pack(pady=10)
        ttk.Label(frame, text="Доступные действия с результатом генерации", font=("Arial", 10), foreground="gray").pack(pady=20)

    def create_templates_tab(self):
        templates_tab = ttk.Frame(self.notebook)
        self.notebook.add(templates_tab, text="Шаблоны")

        list_frame = ttk.LabelFrame(templates_tab, text="Сохранённые шаблоны")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.templates_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set)
        self.templates_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.templates_listbox.yview)
        self.update_templates_list()

        btn_frame = ttk.Frame(templates_tab)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(btn_frame, text="Использовать шаблон", command=self._on_use_template).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Удалить шаблон", command=self._on_delete_template).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Сохранить текущие настройки как шаблон", command=self.save_current_as_template).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Показать настройки", command=self.show_template_settings).pack(side=tk.LEFT, padx=5)

    def _on_use_template(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон из списка.")
            return
        name = self.templates_listbox.get(selection[0])
        self.apply_template(name)

    def _on_delete_template(self):
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон для удаления.")
            return
        name = self.templates_listbox.get(selection[0])
        if messagebox.askyesno("Подтверждение", f"Удалить шаблон '{name}'?"):
            self.delete_template(name)

    def create_about_tab(self):
        about_tab = ttk.Frame(self.notebook)
        self.notebook.add(about_tab, text="О программе")

        info_text = (
            "Генератор кодов\n"
            "Версия: 1.1.2.3\n"
            "Автор: Royzloy\n\n"
            "Описание:\n"
            "Приложение позволяет генерировать коды (строки) по заданным правилам:\n"
            "• Использование цифр (стандартный или уникальный набор), заглавных и строчных букв.\n"
            "• Два режима порядка символов: случайный (заданной длины) или уникальный (по шаблону Б/Ц).\n"
            "• Возможность вставки дефисов через заданный интервал.\n"
            "• Выбор букв: язычный (русский или английский алфавит) или уникальный пользовательский набор.\n"
            "• Генерация нескольких кодов за раз.\n\n"
            "Что нового в версии 1.1.2.3:\n"
            "✓ Добавлена возможность выбора набора цифр (стандартный или уникальный пользовательский).\n"
        )
        text_widget = tk.Text(about_tab, wrap=tk.WORD, font=("Arial", 10), padx=10, pady=10)
        text_widget.insert(tk.END, info_text)
        text_widget.config(state=tk.DISABLED)
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)


if __name__ == "__main__":
    app = CodeGeneratorApp()
    app.mainloop()