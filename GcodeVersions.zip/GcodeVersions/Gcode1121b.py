import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, scrolledtext
import random
import re
import json
import os

class CodeGeneratorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Генератор кодов")
        self.geometry("720x780")
        self.resizable(True, True)

        # Переменные для настроек генерации
        self.use_digits = tk.BooleanVar(value=True)
        self.use_letters = tk.BooleanVar(value=True)
        self.order_mode = tk.StringVar(value="random")   # "random" или "unique"
        self.code_length = tk.IntVar(value=8)
        self.template_str = tk.StringVar(value="")
        self.use_hyphens = tk.BooleanVar(value=False)
        self.hyphen_interval = tk.IntVar(value=3)
        self.letters_mode = tk.StringVar(value="lang")   # "lang" или "custom"
        self.lang_choice = tk.StringVar(value="english") # "russian" или "english"
        self.custom_letters = tk.StringVar(value="")
        self.num_codes = tk.IntVar(value=1)

        # Файл для хранения шаблонов
        self.templates_file = "templates.json"
        self.templates = {}  # словарь {имя_шаблона: словарь_настроек}
        self.load_templates()

        # Создание интерфейса
        self.create_widgets()

        # Начальное обновление состояния полей
        self.update_widgets_state()

    # --------------------------------------------------------------------------
    # Загрузка и сохранение шаблонов
    # --------------------------------------------------------------------------
    def load_templates(self):
        """Загружает шаблоны из JSON-файла."""
        if os.path.exists(self.templates_file):
            try:
                with open(self.templates_file, 'r', encoding='utf-8') as f:
                    self.templates = json.load(f)
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить шаблоны:\n{e}")
                self.templates = {}
        else:
            self.templates = {}

    def save_templates(self):
        """Сохраняет текущие шаблоны в JSON-файл."""
        try:
            with open(self.templates_file, 'w', encoding='utf-8') as f:
                json.dump(self.templates, f, ensure_ascii=False, indent=2)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить шаблоны:\n{e}")

    def get_current_settings(self):
        """Возвращает словарь всех текущих настроек генерации."""
        settings = {
            "use_digits": self.use_digits.get(),
            "use_letters": self.use_letters.get(),
            "order_mode": self.order_mode.get(),
            "random_length": self.code_length.get(),
            "unique_pattern": self.template_str.get().strip(),
            "use_hyphens": self.use_hyphens.get(),
            "hyphen_interval": self.hyphen_interval.get(),
            "letters_mode": self.letters_mode.get(),
            "letters_language": self.lang_choice.get(),
            "custom_letters": self.custom_letters.get().strip().upper(),
            "num_codes": self.num_codes.get()
        }
        return settings

    def apply_settings(self, settings):
        """Применяет настройки из словаря ко всем виджетам."""
        # Устанавливаем значения переменных
        self.use_digits.set(settings.get("use_digits", True))
        self.use_letters.set(settings.get("use_letters", True))
        self.order_mode.set(settings.get("order_mode", "random"))
        self.code_length.set(settings.get("random_length", 8))
        self.template_str.set(settings.get("unique_pattern", ""))
        self.use_hyphens.set(settings.get("use_hyphens", False))
        self.hyphen_interval.set(settings.get("hyphen_interval", 3))
        self.letters_mode.set(settings.get("letters_mode", "lang"))
        self.lang_choice.set(settings.get("letters_language", "english"))
        self.custom_letters.set(settings.get("custom_letters", ""))
        self.num_codes.set(settings.get("num_codes", 1))

        # Обновляем активность/неактивность полей
        self.update_widgets_state()

    def save_current_as_template(self):
        """Сохраняет текущие настройки как новый шаблон."""
        name = simpledialog.askstring("Сохранить шаблон", "Введите имя шаблона:")
        if not name:
            return
        # Проверка, существует ли уже такой шаблон
        if name in self.templates:
            overwrite = messagebox.askyesno("Подтверждение",
                                            f"Шаблон с именем '{name}' уже существует. Перезаписать?")
            if not overwrite:
                return
        # Сохраняем текущие настройки
        self.templates[name] = self.get_current_settings()
        self.save_templates()
        # Обновляем список шаблонов, если вкладка уже создана
        if hasattr(self, 'templates_listbox'):
            self.update_templates_list()
        messagebox.showinfo("Успех", f"Шаблон '{name}' сохранён.")

    def delete_template(self, name):
        """Удаляет шаблон по имени."""
        if name in self.templates:
            del self.templates[name]
            self.save_templates()
            self.update_templates_list()
            messagebox.showinfo("Успех", f"Шаблон '{name}' удалён.")

    def apply_template(self, name):
        """Загружает выбранный шаблон на главную вкладку."""
        if name not in self.templates:
            messagebox.showerror("Ошибка", f"Шаблон '{name}' не найден.")
            return
        settings = self.templates[name]
        self.apply_settings(settings)
        # Переключаемся на главную вкладку
        self.notebook.select(0)
        messagebox.showinfo("Шаблон применён", f"Настройки из шаблона '{name}' загружены.")

    def update_templates_list(self):
        """Обновляет содержимое Listbox на вкладке 'Шаблоны'."""
        if hasattr(self, 'templates_listbox'):
            self.templates_listbox.delete(0, tk.END)
            for name in sorted(self.templates.keys()):
                self.templates_listbox.insert(tk.END, name)

    # --------------------------------------------------------------------------
    # Новый метод: показать детальные настройки выбранного шаблона
    # --------------------------------------------------------------------------
    def show_template_settings(self):
        """Открывает окно с подробными настройками выбранного шаблона."""
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон из списка.")
            return
        name = self.templates_listbox.get(selection[0])
        settings = self.templates.get(name, {})
        if not settings:
            messagebox.showerror("Ошибка", f"Не удалось загрузить настройки шаблона '{name}'.")
            return

        # Создаём окно
        win = tk.Toplevel(self)
        win.title(f"Настройки шаблона: {name}")
        win.geometry("500x450")
        win.resizable(True, True)

        # Текстовая область с прокруткой
        text_frame = ttk.Frame(win)
        text_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar = ttk.Scrollbar(text_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        text_widget = tk.Text(text_frame, wrap=tk.WORD, yscrollcommand=scrollbar.set,
                              font=("Courier", 10), padx=5, pady=5)
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=text_widget.yview)

        # Форматируем вывод
        lines = []
        lines.append(f"Имя шаблона: {name}")
        lines.append("")

        # Цифры и буквы
        use_digits = settings.get("use_digits", True)
        use_letters = settings.get("use_letters", True)
        lines.append(f"Использовать цифры: {'Да' if use_digits else 'Нет'}")
        lines.append(f"Использовать буквы: {'Да' if use_letters else 'Нет'}")
        lines.append("")

        # Порядок
        order_mode = settings.get("order_mode", "random")
        if order_mode == "random":
            random_length = settings.get("random_length", 8)
            lines.append(f"Порядок: Рандомный")
            lines.append(f"Длина кода (рандомный): {random_length}")
        else:
            unique_pattern = settings.get("unique_pattern", "")
            lines.append(f"Порядок: Уникальный (по шаблону)")
            lines.append(f"Шаблон порядка (Б/Ц): {unique_pattern if unique_pattern else '(не задан)'}")
        lines.append("")

        # Дефисы
        use_hyphens = settings.get("use_hyphens", False)
        if use_hyphens:
            interval = settings.get("hyphen_interval", 3)
            lines.append(f"Дефисы: Да, через каждые {interval} символов")
        else:
            lines.append("Дефисы: Нет")
        lines.append("")

        # Буквы
        letters_mode = settings.get("letters_mode", "lang")
        if letters_mode == "lang":
            lang = settings.get("letters_language", "english")
            lang_text = "Русский" if lang == "russian" else "Английский"
            lines.append(f"Буквы: Язычный, {lang_text}")
        else:
            custom = settings.get("custom_letters", "")
            lines.append(f"Буквы: Уникальный, набор = {custom if custom else '(не задан)'}")
        lines.append("")

        # Количество кодов
        num_codes = settings.get("num_codes", 1)
        lines.append(f"Количество кодов: {num_codes}")

        # Вставляем в текстовое поле
        text_widget.insert(tk.END, "\n".join(lines))
        text_widget.config(state=tk.DISABLED)  # только для чтения

        # Кнопка закрытия
        btn_frame = ttk.Frame(win)
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        close_btn = ttk.Button(btn_frame, text="Закрыть", command=win.destroy)
        close_btn.pack()

    # --------------------------------------------------------------------------
    # Вспомогательные методы (логика генерации)
    # --------------------------------------------------------------------------
    def get_letter_pool(self):
        """Возвращает строку из доступных букв согласно настройкам."""
        if self.letters_mode.get() == "lang":
            if self.lang_choice.get() == "russian":
                return "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ"
            else:
                return "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        else:
            return self.custom_letters.get().strip().upper()

    def generate_random_code(self, length, digits_enabled, letters_enabled, letter_pool):
        """Генерация кода в случайном порядке."""
        pool = []
        if digits_enabled:
            pool.extend("0123456789")
        if letters_enabled:
            pool.extend(letter_pool)
        return ''.join(random.choice(pool) for _ in range(length))

    def generate_unique_code(self, template, digits_enabled, letters_enabled, letter_pool):
        """Генерация кода по шаблону (Б/Ц)."""
        code_chars = []
        for ch in template:
            if ch == 'Б':
                if not letters_enabled:
                    raise ValueError("Буквы не разрешены, но шаблон требует букву")
                code_chars.append(random.choice(letter_pool))
            elif ch == 'Ц':
                if not digits_enabled:
                    raise ValueError("Цифры не разрешены, но шаблон требует цифру")
                code_chars.append(random.choice("0123456789"))
            else:
                raise ValueError(f"Недопустимый символ в шаблоне: {ch}")
        return ''.join(code_chars)

    def insert_hyphens(self, code, interval):
        """Вставляет дефисы в строку через каждые interval символов."""
        if interval <= 0:
            return code
        parts = [code[i:i+interval] for i in range(0, len(code), interval)]
        return '-'.join(parts)

    def update_widgets_state(self):
        """Обновляет состояние полей в зависимости от выбранных опций."""
        # Порядок символов
        if self.order_mode.get() == "random":
            self.length_entry.config(state="normal")
            self.template_entry.config(state="disabled")
        else:
            self.length_entry.config(state="disabled")
            self.template_entry.config(state="normal")

        # Дефисы
        if self.use_hyphens.get():
            self.interval_entry.config(state="normal")
        else:
            self.interval_entry.config(state="disabled")

        # Буквы
        if self.letters_mode.get() == "lang":
            # Включаем радиокнопки выбора языка, отключаем поле уникального набора
            for rb in self.lang_radiobuttons:
                rb.config(state="normal")
            self.custom_entry.config(state="disabled")
        else:
            for rb in self.lang_radiobuttons:
                rb.config(state="disabled")
            self.custom_entry.config(state="normal")

    def generate_codes(self):
        """Основная функция генерации кодов."""
        # Сброс вывода
        self.output_text.delete(1.0, tk.END)

        # Проверка: хотя бы один тип символов
        digits_enabled = self.use_digits.get()
        letters_enabled = self.use_letters.get()
        if not digits_enabled and not letters_enabled:
            messagebox.showerror("Ошибка", "Необходимо выбрать хотя бы один тип символов: цифры или буквы.")
            return

        # Количество кодов
        try:
            num = self.num_codes.get()
            if num <= 0:
                raise ValueError
        except:
            messagebox.showerror("Ошибка", "Количество кодов должно быть положительным целым числом.")
            return

        # Набор букв (если нужен)
        letter_pool = ""
        if letters_enabled:
            if self.letters_mode.get() == "lang":
                letter_pool = self.get_letter_pool()
            else:
                custom = self.custom_letters.get().strip().upper()
                if not custom:
                    messagebox.showerror("Ошибка", "В режиме 'Уникальный набор букв' необходимо указать набор букв.")
                    return
                letter_pool = custom

        # Параметры порядка
        mode = self.order_mode.get()
        if mode == "random":
            try:
                length = self.code_length.get()
                if length <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Длина кода должна быть положительным целым числом.")
                return
        else:  # unique
            template = self.template_str.get().strip().upper()
            if not template:
                messagebox.showerror("Ошибка", "Шаблон не может быть пустым.")
                return
            if not re.fullmatch(r'[БЦ]+', template):
                messagebox.showerror("Ошибка", "Шаблон может содержать только символы 'Б' и 'Ц'.")
                return
            if 'Б' in template and not letters_enabled:
                messagebox.showerror("Ошибка", "Шаблон содержит буквы ('Б'), но использование букв отключено.")
                return
            if 'Ц' in template and not digits_enabled:
                messagebox.showerror("Ошибка", "Шаблон содержит цифры ('Ц'), но использование цифр отключено.")
                return
            length = len(template)

        # Дефисы
        use_hyphens = self.use_hyphens.get()
        interval = None
        if use_hyphens:
            try:
                interval = self.hyphen_interval.get()
                if interval <= 0:
                    raise ValueError
            except:
                messagebox.showerror("Ошибка", "Интервал для дефисов должен быть положительным целым числом.")
                return

        # Генерация кодов
        codes = []
        for _ in range(num):
            try:
                if mode == "random":
                    code = self.generate_random_code(length, digits_enabled, letters_enabled, letter_pool)
                else:
                    template = self.template_str.get().strip().upper()
                    code = self.generate_unique_code(template, digits_enabled, letters_enabled, letter_pool)
                if use_hyphens:
                    code = self.insert_hyphens(code, interval)
                codes.append(code)
            except Exception as e:
                messagebox.showerror("Ошибка генерации", str(e))
                return

        # Вывод
        self.output_text.insert(1.0, "\n".join(codes))

    # --------------------------------------------------------------------------
    # Построение интерфейса
    # --------------------------------------------------------------------------
    def create_widgets(self):
        # Создаём Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Вкладки
        self.create_main_tab()
        self.create_templates_tab()
        self.create_about_tab()

    def create_main_tab(self):
        """Создаёт вкладку «Главная» со всеми элементами управления."""
        main_tab = ttk.Frame(self.notebook)
        self.notebook.add(main_tab, text="Главная")

        # Основной контейнер с прокруткой на случай маленького окна
        canvas = tk.Canvas(main_tab)
        scrollbar = ttk.Scrollbar(main_tab, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # --- Виджеты внутри scrollable_frame ---
        # 1. Чекбоксы символов
        chars_frame = ttk.LabelFrame(scrollable_frame, text="Используемые символы")
        chars_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Checkbutton(chars_frame, text="Цифры (0-9)", variable=self.use_digits,
                        command=self.update_widgets_state).pack(side=tk.LEFT, padx=10, pady=5)
        ttk.Checkbutton(chars_frame, text="Буквы (заглавные)", variable=self.use_letters,
                        command=self.update_widgets_state).pack(side=tk.LEFT, padx=10, pady=5)

        # 2. Порядок символов
        order_frame = ttk.LabelFrame(scrollable_frame, text="Порядок символов")
        order_frame.pack(fill=tk.X, pady=5, padx=5)
        ttk.Radiobutton(order_frame, text="Рандомный (длина кода)", variable=self.order_mode,
                        value="random", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(order_frame, text="Уникальный (шаблон Б/Ц)", variable=self.order_mode,
                        value="unique", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        length_frame = ttk.Frame(order_frame)
        length_frame.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(length_frame, text="Длина кода:").pack(side=tk.LEFT)
        self.length_entry = ttk.Entry(length_frame, textvariable=self.code_length, width=6)
        self.length_entry.pack(side=tk.LEFT, padx=5)

        template_frame = ttk.Frame(order_frame)
        template_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(template_frame, text="Шаблон (Б=буква, Ц=цифра):").pack(side=tk.LEFT)
        self.template_entry = ttk.Entry(template_frame, textvariable=self.template_str, width=20)
        self.template_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(template_frame, text="Пример: ББЦЦЦ").pack(side=tk.LEFT, padx=5)

        # 3. Дефисы
        hyphens_frame = ttk.LabelFrame(scrollable_frame, text="Дефисы")
        hyphens_frame.pack(fill=tk.X, pady=5, padx=5)
        self.hyphens_check = ttk.Checkbutton(hyphens_frame, text="Использовать дефисы",
                                             variable=self.use_hyphens, command=self.update_widgets_state)
        self.hyphens_check.pack(side=tk.LEFT, padx=10, pady=5)
        interval_frame = ttk.Frame(hyphens_frame)
        interval_frame.pack(side=tk.LEFT, padx=10, pady=5)
        ttk.Label(interval_frame, text="Через каждые N символов:").pack(side=tk.LEFT)
        self.interval_entry = ttk.Entry(interval_frame, textvariable=self.hyphen_interval, width=5)
        self.interval_entry.pack(side=tk.LEFT, padx=5)

        # 4. Набор букв
        letters_frame = ttk.LabelFrame(scrollable_frame, text="Набор букв")
        letters_frame.pack(fill=tk.X, pady=5, padx=5)

        ttk.Radiobutton(letters_frame, text="Язычный", variable=self.letters_mode,
                        value="lang", command=self.update_widgets_state).grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
        ttk.Radiobutton(letters_frame, text="Уникальный (пользовательский)", variable=self.letters_mode,
                        value="custom", command=self.update_widgets_state).grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)

        lang_subframe = ttk.Frame(letters_frame)
        lang_subframe.grid(row=0, column=1, padx=10, pady=2, sticky=tk.W)
        rb1 = ttk.Radiobutton(lang_subframe, text="Русский", variable=self.lang_choice, value="russian")
        rb2 = ttk.Radiobutton(lang_subframe, text="Английский", variable=self.lang_choice, value="english")
        rb1.pack(side=tk.LEFT, padx=5)
        rb2.pack(side=tk.LEFT, padx=5)
        self.lang_radiobuttons = [rb1, rb2]

        custom_frame = ttk.Frame(letters_frame)
        custom_frame.grid(row=1, column=1, padx=10, pady=2, sticky=tk.W)
        ttk.Label(custom_frame, text="Набор букв:").pack(side=tk.LEFT)
        self.custom_entry = ttk.Entry(custom_frame, textvariable=self.custom_letters, width=20)
        self.custom_entry.pack(side=tk.LEFT, padx=5)
        ttk.Label(custom_frame, text="(только заглавные, пример: ABCXYZ)").pack(side=tk.LEFT, padx=5)

        # 5. Количество кодов, кнопки "Сгенерировать" и "Сохранить в шаблон"
        control_frame = ttk.Frame(scrollable_frame)
        control_frame.pack(fill=tk.X, pady=10, padx=5)
        ttk.Label(control_frame, text="Количество кодов:").pack(side=tk.LEFT, padx=5)
        self.num_codes_entry = ttk.Entry(control_frame, textvariable=self.num_codes, width=6)
        self.num_codes_entry.pack(side=tk.LEFT, padx=5)
        self.generate_btn = ttk.Button(control_frame, text="Сгенерировать", command=self.generate_codes)
        self.generate_btn.pack(side=tk.LEFT, padx=10)
        self.save_template_btn = ttk.Button(control_frame, text="Сохранить в шаблон", command=self.save_current_as_template)
        self.save_template_btn.pack(side=tk.LEFT, padx=10)

        # 6. Поле вывода
        output_frame = ttk.LabelFrame(scrollable_frame, text="Результат")
        output_frame.pack(fill=tk.BOTH, expand=True, pady=5, padx=5)
        self.output_text = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD, height=12)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def create_templates_tab(self):
        """Создаёт вкладку «Шаблоны» со списком и кнопками управления."""
        templates_tab = ttk.Frame(self.notebook)
        self.notebook.add(templates_tab, text="Шаблоны")

        # Рамка для списка
        list_frame = ttk.LabelFrame(templates_tab, text="Сохранённые шаблоны")
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Listbox и скроллбар
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.templates_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set)
        self.templates_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.templates_listbox.yview)

        # Заполняем список
        self.update_templates_list()

        # Кнопки управления
        btn_frame = ttk.Frame(templates_tab)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)

        use_btn = ttk.Button(btn_frame, text="Использовать шаблон",
                             command=lambda: self._on_use_template())
        use_btn.pack(side=tk.LEFT, padx=5)

        delete_btn = ttk.Button(btn_frame, text="Удалить шаблон",
                                command=lambda: self._on_delete_template())
        delete_btn.pack(side=tk.LEFT, padx=5)

        save_btn = ttk.Button(btn_frame, text="Сохранить текущие настройки как шаблон",
                              command=self.save_current_as_template)
        save_btn.pack(side=tk.LEFT, padx=5)

        # НОВАЯ КНОПКА: Показать настройки
        show_btn = ttk.Button(btn_frame, text="Показать настройки",
                              command=self.show_template_settings)
        show_btn.pack(side=tk.LEFT, padx=5)

    def _on_use_template(self):
        """Обработчик кнопки 'Использовать шаблон'."""
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон из списка.")
            return
        name = self.templates_listbox.get(selection[0])
        self.apply_template(name)

    def _on_delete_template(self):
        """Обработчик кнопки 'Удалить шаблон'."""
        selection = self.templates_listbox.curselection()
        if not selection:
            messagebox.showwarning("Предупреждение", "Выберите шаблон для удаления.")
            return
        name = self.templates_listbox.get(selection[0])
        if messagebox.askyesno("Подтверждение", f"Удалить шаблон '{name}'?"):
            self.delete_template(name)

    def create_about_tab(self):
        """Создаёт вкладку «О программе» с информацией."""
        about_tab = ttk.Frame(self.notebook)
        self.notebook.add(about_tab, text="О программе")

        # Информационный текст
        info_text = (
            "Генератор кодов\n"
            "Версия: 1.1.2.1b\n"
            "Автор: Royzloy\n\n"
            "Описание:\n"
            "Приложение позволяет генерировать коды (строки) по заданным правилам:\n"
            "• Использование цифр и/или букв (заглавных).\n"
            "• Два режима порядка символов: случайный (заданной длины) или уникальный (по шаблону Б/Ц).\n"
            "• Возможность вставки дефисов через заданный интервал.\n"
            "• Выбор букв: язычный (русский или английский алфавит) или уникальный пользовательский набор.\n"
            "• Генерация нескольких кодов за раз.\n\n"
            "Что нового в версии 1.1.2.1b:\n"
            "✓ Добавлена система вкладок.\n"
            "✓ Возможность сохранять настройки в шаблоны.\n"
            "✓ Загрузка, использование и удаление шаблонов.\n"
            "✓ Страница «О программе».\n"
            "✓ Добавлен просмотр детальных настроек шаблона.\n"
        )
        text_widget = tk.Text(about_tab, wrap=tk.WORD, font=("Arial", 10), padx=10, pady=10)
        text_widget.insert(tk.END, info_text)
        text_widget.config(state=tk.DISABLED)  # только для чтения
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)


if __name__ == "__main__":
    app = CodeGeneratorApp()
    app.mainloop()